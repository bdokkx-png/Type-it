# PORTAL — two screens, one world

A real-time 2-player browser experience where a glowing ball leaves one Chromebook and appears on the other. Features:

- Private 5-character room codes and invite links
- Server-authoritative gravity, bouncing, and cross-screen handoffs (Socket.IO)
- Webcam thumb/index pinch tracking through MediaPipe Hand Landmarker (processed entirely in the browser)
- Trackpad/mouse drag-to-throw fallback
- Screen-specific portal edges, particle effects, sound, multiplayer indicators, and reset

## Start on your Chromebook (Linux development environment enabled)

```bash
cd portal-throw
npm install
npm start
```

Open `http://localhost:3000` in your Chromebook Chrome browser.

**For TWO different Chromebooks**: deploy the site to an HTTPS host, e.g., Render, because browser cameras generally require HTTPS (except localhost). Push this folder to a GitHub repository, then create a Render **Web Service** connected to that repo. Set build command to `npm install` and start command to `npm start`; a `render.yaml` is also included. Visit your deployed `https://...onrender.com` link on BOTH Chromebooks. One person creates a room and shares the invite link; the other joins. Ensure both can access the public server (school Wi-Fi may block connections or the model CDN).

**Position your devices**: the first person to join (Player 1) should put their Chromebook on the LEFT; Player 2 should place theirs on the RIGHT. Throw toward the center: Player 1 throws right; Player 2 throws left. Drag the ball by mouse if camera tracking isn't available.

## Hand gesture technique

Enable hand tracking and allow browser camera access. Put your hand into view; a small camera preview shows the detected skeleton. The full stage corresponds to the camera's mirrored frame. Pinch index finger and thumb CLOSE TO the rendered ball, move your pinched hand toward the portal edge, and open the fingers to release. The browser sends **hand position and throw velocity only**, never webcam video. A network connection is required to initially load the MediaPipe code and model from the CDN.

## Troubleshooting

- **Camera blocked**: access via HTTPS or `http://localhost`; check site permissions.
- **Cannot detect hand**: brighter lighting, full hand visible, move farther from camera.
- **Ball won't grab**: pinch near the ball's position on the stage; use mouse to position it if needed.
- **Friend cannot join**: both players must be on the exact same deployed host and enter the same code. Rooms live in server memory and vanish if the server restarts.
- **No transfer**: throw to the adjacent edge (right for Player 1, left for Player 2) with enough speed. Ball transfers only while both players are connected.
- **School firewall**: WebSocket or Google/CDN domains may be restricted; try a permitted network.

This is a fun prototype, not a low-latency production physics engine: on long/high-latency links the throw can appear slightly delayed. It assumes **one server instance** because rooms are in memory.
