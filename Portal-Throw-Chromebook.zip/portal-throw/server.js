'use strict';
const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');
const app = express();
app.disable('x-powered-by');
app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_, res) => res.json({ ok: true }));
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: false }, maxHttpBufferSize: 16_384 });
const rooms = new Map();
const R = 0.037;
const GRAVITY = 0.84;
const MAX_SPEED = 2.7;
const now = () => Date.now();
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const codeValid = code => /^[A-Z2-9]{5}$/.test(code);
const codeGen = () => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do { code = Array.from({length:5}, () => chars[Math.floor(Math.random() * chars.length)]).join(''); } while(rooms.has(code));
  return code;
};
const newBall = () => ({ x: 0.50, y: 0.42, vx: 0, vy: 0, owner: 0, heldBy: null, spin: 0, lastTouched: 0 });
function makeRoom(code) {
  const room = { code, players: [null,null], ball: newBall(), transfers: 0, lastActive: now(), seq: 0 };
  rooms.set(code, room);
  return room;
}
function publicState(room) {
  return { code: room.code, players: room.players.map((id, slot) => ({ slot, connected: !!id })), ball: room.ball, transfers: room.transfers, seq: room.seq++ };
}
function publish(room) { io.to(room.code).emit('state', publicState(room)); }
function getRoomAndSlot(socket) {
  const code = socket.data.code;
  const room = rooms.get(code);
  if (!room) return {};
  const slot = room.players.indexOf(socket.id);
  if (slot < 0) return {};
  return {room, slot};
}
function validVec(p) { return p && Number.isFinite(p.x) && Number.isFinite(p.y); }
function detach(socket) {
  const {room, slot} = getRoomAndSlot(socket);
  if (!room) return;
  room.players[slot] = null;
  if (room.ball.heldBy === slot) room.ball.heldBy = null;
  if (room.ball.owner === slot && room.players[1-slot]) {
    room.ball.owner = 1-slot;
    room.ball.x = 0.5; room.ball.y = 0.35; room.ball.vx = 0; room.ball.vy = 0;
  }
  room.lastActive = now();
  socket.leave(room.code);
  delete socket.data.code;
  io.to(room.code).emit('toast', 'A player disconnected.');
  publish(room);
  if (!room.players.some(Boolean)) rooms.delete(room.code);
}
function join(socket, room, done) {
  if (socket.data.code) detach(socket);
  const slot = room.players.indexOf(null);
  if (slot < 0) return done({ ok: false, error: 'Room full — only two players can join.' });
  room.players[slot] = socket.id;
  room.lastActive = now();
  socket.data.code = room.code;
  socket.join(room.code);
  done({ ok: true, code: room.code, slot });
  publish(room);
  io.to(room.code).emit('toast', slot === 0 ? 'Room created. Invite a friend!' : 'Player 2 connected. Ready to throw!');
}
io.on('connection', socket => {
  socket.on('create', (_, done) => {
    if (typeof done !== 'function') return;
    join(socket, makeRoom(codeGen()), done);
  });
  socket.on('join', (input, done) => {
    if (typeof done !== 'function') return;
    const code = String(input?.code || '').trim().toUpperCase();
    if (!codeValid(code)) return done({ ok: false, error: 'Enter a valid 5-character room code.' });
    const room = rooms.get(code);
    if (!room) return done({ ok: false, error: 'Room not found. Ask your friend for their current code.' });
    join(socket, room, done);
  });
  socket.on('grab', (point) => {
    const { room, slot } = getRoomAndSlot(socket);
    if (!room || room.ball.owner !== slot || room.ball.heldBy !== null || !validVec(point)) return;
    const x = clamp(point.x, R, 1-R), y = clamp(point.y, R, 1-R);
    if (Math.hypot(x-room.ball.x, y-room.ball.y) > 0.22) return;
    room.ball.heldBy = slot;
    room.ball.vx = 0; room.ball.vy = 0;
    room.ball.x = x; room.ball.y = y;
    room.lastActive = now();
    publish(room);
  });
  socket.on('move', (point) => {
    const {room,slot} = getRoomAndSlot(socket);
    if (!room || room.ball.heldBy !== slot || !validVec(point)) return;
    room.ball.x = clamp(point.x, R, 1-R); room.ball.y = clamp(point.y, R, 1-R);
    room.lastActive = now();
  });
  socket.on('throw', (move) => {
    const {room,slot} = getRoomAndSlot(socket);
    if (!room || room.ball.heldBy !== slot || !move || !Number.isFinite(move.vx) || !Number.isFinite(move.vy)) return;
    room.ball.vx = clamp(move.vx, -MAX_SPEED, MAX_SPEED);
    room.ball.vy = clamp(move.vy, -MAX_SPEED, MAX_SPEED);
    room.ball.heldBy = null;
    room.ball.lastTouched = now();
    room.lastActive = now();
    io.to(room.code).emit('throw-effect', { slot, x: room.ball.x, y: room.ball.y });
    publish(room);
  });
  socket.on('reset', () => {
    const {room} = getRoomAndSlot(socket);
    if (!room) return;
    room.ball = newBall();
    room.ball.owner = room.players[0] ? 0 : 1;
    room.lastActive = now();
    publish(room);
  });
  socket.on('disconnect', () => detach(socket));
});
let prev = process.hrtime.bigint();
setInterval(() => {
  const current = process.hrtime.bigint();
  const dt = clamp(Number(current - prev) / 1e9, 0, 0.05);
  prev = current;
  for (const room of rooms.values()) {
    const b = room.ball;
    if (b.heldBy === null) {
      b.vy += GRAVITY * dt;
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.spin += b.vx * dt * 8;
      if (b.y > 1 - R) { b.y = 1-R; b.vy = -Math.abs(b.vy)*0.69; b.vx *= 0.93; if (Math.abs(b.vy)<0.075) b.vy=0; }
      if (b.y < R) { b.y = R; b.vy = Math.abs(b.vy)*0.72; }
      // Facing screens: slot 0 (left) throws out the right edge; slot 1 (right) throws out the left edge.
      const isOutgoing = (b.owner === 0 && b.x > 1+R) || (b.owner === 1 && b.x < -R);
      if (isOutgoing && room.players[1-b.owner]) {
        const previous = b.owner;
        b.owner = 1 - b.owner;
        b.x = previous === 0 ? -R : 1+R;
        room.transfers++;
        io.to(room.code).emit('transfer', { from:previous, to:b.owner, y:b.y, speed:Math.hypot(b.vx,b.vy) });
      } else if (b.x < R && b.owner === 0 || b.x > 1-R && b.owner === 1) {
        // If thrown away from the adjacent screen, bounce off outer edge.
        if (b.owner === 0 && b.x < R) { b.x = R; b.vx = Math.abs(b.vx)*0.78; }
        if (b.owner === 1 && b.x > 1-R) { b.x = 1-R; b.vx = -Math.abs(b.vx)*0.78; }
      } else if (isOutgoing) { // No friend online: keep the ball on your own display.
        b.x = b.owner === 0 ? 1-R : R;
        b.vx = -b.vx * 0.75;
      }
      if (b.y >= 1-R && Math.abs(b.vx)<0.004) b.vx=0;
    }
    if (room.players.some(Boolean)) publish(room);
    if (now()-room.lastActive > 1000*60*60*3) rooms.delete(room.code);
  }
}, 1000/30);
const PORT = Number(process.env.PORT || 3000);
if (require.main === module) server.listen(PORT, '0.0.0.0', () => console.log(`Portal Throw listening on http://localhost:${PORT}`));
module.exports = {app, server, io, rooms};
