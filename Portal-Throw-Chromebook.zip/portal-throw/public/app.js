const $ = id => document.getElementById(id);
const socket = io({ reconnection: true });
let slot = -1, room = '', state = null, held = false, pointerDown = false;
let activeSource = null, handEnabled = false, handTracker = null, handStream = null, handLoopActive = false;
let handPinch = false, gesturePos = null, lastMoveSent = 0, lastHandFrame = -1;
let ballVisual = {x: .5,y: .42}, particles = [], transferFlash = 0, toastTimeout;
let cameraLoading = false;
const canvas = $('arena'), ctx = canvas.getContext('2d');
const handCanvas = $('handOverlay'), hctx = handCanvas.getContext('2d');
const video = $('camera');
const history = [];
const clamp = (v,a,b) => Math.min(b,Math.max(a,v));
const lerp = (a,b,t) => a+(b-a)*t;
function toast(msg){ $('toast').textContent=msg; $('toast').classList.remove('hidden'); clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>$('toast').classList.add('hidden'),3500); }
function updateNet(connected){$('netStatus').classList.toggle('offline',!connected); $('netStatus').innerHTML=`<span class="status-light"></span> ${connected?'ONLINE':'OFFLINE'}`;}
socket.on('connect',()=>{updateNet(true); if(room){const oldRoom=room;room='';enterRoom('join',oldRoom);}});
socket.on('disconnect',()=>{updateNet(false);held=false;handPinch=false;toast('Connection lost — reconnecting.');});
socket.on('state', s=>{
 if(s.code!==room)return;
 const oldOwner=state?.ball?.owner;
 state=s;
 $('transferCount').textContent=String(s.transfers).padStart(2,'0');
 $('friendState').textContent=s.players[1-slot]?.connected?'CONNECTED · READY':'WAITING FOR FRIEND';
 $('waiting').classList.toggle('hidden',s.players.every(p=>p.connected));
 if(oldOwner!==undefined&&oldOwner!==s.ball.owner){held=false;activeSource=null;history.length=0;}
 $('arenaStatus').textContent=s.ball.owner===slot?'BALL ON YOUR SCREEN':'BALL ON FRIEND’S SCREEN';
});
socket.on('toast', msg => { if(room)toast(msg); });
socket.on('transfer', ({from,to,y,speed})=>{
 transferFlash=1;
 for(let i=0;i<35;i++) particles.push({x:to===slot?(to===0?1:0):(from===0?1:0),y, vx:(Math.random()-.5)*.6,vy:(Math.random()-.5)*.6,life:1,r:Math.random()*3+1});
 if(to===slot){toast('INCOMING! Catch it ✦'); playTone(500,700);}else if(from===slot){toast('PORTAL TRANSFER COMPLETE ↗');playTone(750,400);}
});
socket.on('throw-effect', ({slot:who,x,y})=>{if(who!==slot)return;for(let i=0;i<22;i++) particles.push({x,y,vx:(Math.random()-.5)*.5,vy:(Math.random()-.5)*.5,life:1,r:Math.random()*2.5+1});});
let audioContext;
function playTone(start,end){try{audioContext??=new AudioContext();const o=audioContext.createOscillator(),g=audioContext.createGain();o.type='sine';o.frequency.setValueAtTime(start,audioContext.currentTime);o.frequency.exponentialRampToValueAtTime(end,audioContext.currentTime+.22);g.gain.setValueAtTime(.055,audioContext.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioContext.currentTime+.24);o.connect(g).connect(audioContext.destination);o.start();o.stop(audioContext.currentTime+.25);}catch{}}
function enterRoom(action,code){
 if(!socket.connected){$('joinError').textContent='Still connecting to server. Try again.';return;}
 const event=action==='create'?'create':'join';
 socket.emit(event,event==='create'?{}:{code}, result=>{
  if(!result?.ok){$('joinError').textContent=result?.error||'Could not join room.';toast(result?.error||'Could not join room.');return;}
  room=result.code; slot=result.slot; state=null;
  $('roomCode').textContent=room;
  $('youLabel').textContent=slot===0?'YOU · LEFT SCREEN':'YOU · RIGHT SCREEN';
  $('friendLabel').textContent=slot===0?'FRIEND · RIGHT SCREEN':'FRIEND · LEFT SCREEN';
  document.querySelector('.left-label').textContent=slot===0?'← OUTER EDGE':'← PORTAL EDGE';
  document.querySelector('.right-label').textContent=slot===0?'PORTAL EDGE →':'OUTER EDGE →';
  $('landing').classList.add('hidden');$('game').classList.remove('hidden');
  history.replaceState({},'',`/?room=${room}`);
  $('waiting').classList.remove('hidden');
 });
}
// No-op view placeholder intentionally omitted.
$('createBtn').addEventListener('click',()=>enterRoom('create'));
$('joinBtn').addEventListener('click',()=>enterRoom('join',$('joinCode').value.toUpperCase()));
$('joinCode').addEventListener('keydown',e=>{if(e.key==='Enter')$('joinBtn').click();});
$('joinCode').addEventListener('input',e=>e.target.value=e.target.value.toUpperCase().replace(/[^A-Z2-9]/g,''));
function copyInvite(){if(!room)return;const link=`${location.origin}/?room=${room}`;navigator.clipboard?.writeText(link).then(()=>toast('Invite link copied!')).catch(()=>{prompt('Copy your invite link:',link);});}
$('copyBtn').addEventListener('click',copyInvite);$('copyWaiting').addEventListener('click',copyInvite);
$('resetBtn').addEventListener('click',()=>socket.emit('reset'));
$('leaveBtn').addEventListener('click',()=>{shutdownCamera();location.href='/';});
window.addEventListener('keydown',e=>{if(e.key.toLowerCase()==='r'&&room&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName))socket.emit('reset');});
const queryCode=new URLSearchParams(location.search).get('room');
if(queryCode){$('joinCode').value=queryCode.toUpperCase();socket.connected?enterRoom('join',queryCode.toUpperCase()):socket.once('connect',()=>enterRoom('join',queryCode.toUpperCase()));}
function pointFromEvent(e){const rect=canvas.getBoundingClientRect();return {x:clamp((e.clientX-rect.left)/rect.width,0,1), y:clamp((e.clientY-rect.top)/rect.height,0,1)};}
function pushSample(p){history.push({...p,t:performance.now()});while(history.length>12||history.length>1&&history[0].t<performance.now()-170)history.shift();}
function velocity(){if(history.length<2)return {vx:0,vy:-.15}; const a=history[0],b=history[history.length-1],dt=Math.max(.03,(b.t-a.t)/1000);return {vx:clamp((b.x-a.x)/dt,-2.7,2.7),vy:clamp((b.y-a.y)/dt,-2.7,2.7)};}
function canGrab(p){return state&&state.ball.owner===slot&&state.ball.heldBy===null&&Math.hypot(p.x-state.ball.x,p.y-state.ball.y)<.22;}
function startGrab(p,source){if(!canGrab(p)||held)return false;activeSource=source;held=true;history.length=0;pushSample(p);socket.emit('grab',p);return true;}
function moveGrab(p){if(!held)return;pushSample(p);const t=performance.now();if(t-lastMoveSent>25){socket.emit('move',p);lastMoveSent=t;}}
function endGrab(){if(!held)return;const v=velocity();socket.emit('throw',v);held=false;activeSource=null;history.length=0;}
canvas.addEventListener('pointerdown',e=>{if(slot<0)return;const p=pointFromEvent(e);if(startGrab(p,'pointer')){pointerDown=true;canvas.setPointerCapture(e.pointerId);}});
canvas.addEventListener('pointermove',e=>{if(pointerDown&&activeSource==='pointer')moveGrab(pointFromEvent(e));});
canvas.addEventListener('pointerup',()=>{if(pointerDown){pointerDown=false;endGrab();}});
canvas.addEventListener('pointercancel',()=>{pointerDown=false;if(activeSource==='pointer')endGrab();});
async function enableCamera(){
 if(cameraLoading||handEnabled)return;
 if(!navigator.mediaDevices?.getUserMedia){toast('Camera needs HTTPS (or localhost). Open your deployed HTTPS site.');return;}
 cameraLoading=true;$('cameraBtn').disabled=true;$('cameraBtn').textContent='Loading tracker…';
 try{
  const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:640},height:{ideal:480}},audio:false});
  handStream=stream;video.srcObject=stream;await video.play();
  const vision=await import('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.22/+esm');
  const fileset=await vision.FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.22/wasm');
  try{handTracker=await vision.HandLandmarker.createFromOptions(fileset,{baseOptions:{modelAssetPath:'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',delegate:'GPU'},runningMode:'VIDEO',numHands:1,minHandDetectionConfidence:.55,minTrackingConfidence:.5});}
  catch{handTracker=await vision.HandLandmarker.createFromOptions(fileset,{baseOptions:{modelAssetPath:'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',delegate:'CPU'},runningMode:'VIDEO',numHands:1});}
  handEnabled=true;handLoopActive=true;
  $('cameraBtn').disabled=false;$('cameraBtn').textContent='◉ Disable camera';$('cameraState').textContent='TRACKING';
  $('instructionTitle').textContent='Pinch. Move. Release.';
  $('instructionText').textContent='Pinch near the glowing ball, swing your hand toward your friend, then open your fingers.';
  trackHands();toast('Hand tracking enabled. Move your hand into the camera view.');
 }catch(err){console.error('Camera/tracker:',err);toast('Camera unavailable: check permissions or tracking CDN. Mouse throwing still works.');shutdownCamera();}
 finally{cameraLoading=false;$('cameraBtn').disabled=false;if(!handEnabled)$('cameraBtn').textContent='◉ Enable hand tracking';}
}
function shutdownCamera(){handLoopActive=false;handEnabled=false;handPinch=false;if(activeSource==='hand')endGrab();handStream?.getTracks().forEach(t=>t.stop());handStream=null;video.srcObject=null;handTracker?.close();handTracker=null;hctx.clearRect(0,0,handCanvas.width,handCanvas.height);$('cameraState').textContent='OFFLINE';$('gestureState').textContent='Enable camera to track';$('cameraBtn').textContent='◉ Enable hand tracking';}
$('cameraBtn').addEventListener('click',()=>handEnabled?shutdownCamera():enableCamera());
function trackHands(){
 if(!handLoopActive||!handTracker)return;
 if(video.readyState>=2&&video.currentTime!==lastHandFrame){
  lastHandFrame=video.currentTime;
  try{
   const result=handTracker.detectForVideo(video,performance.now());
   const landmarks=result.landmarks?.[0];
   handCanvas.width=video.videoWidth||640;handCanvas.height=video.videoHeight||480;
   if(landmarks){
    const thumb=landmarks[4],index=landmarks[8];
    // Display mirrored feed, so mirror both the hand dots and the arena X position.
    const p={x:clamp(1-(thumb.x+index.x)/2,0,1),y:clamp((thumb.y+index.y)/2,0,1)};
    gesturePos=p;
    const dist=Math.hypot(thumb.x-index.x,thumb.y-index.y);
    const pinch=handPinch?dist<.075:dist<.055; // hysteresis reduces accidental drops
    const bones=[[0,1,2,3,4],[0,5,6,7,8],[0,9,10,11,12],[0,13,14,15,16],[0,17,18,19,20],[5,9,13,17]];
    hctx.lineWidth=3;hctx.strokeStyle='#62ecff';hctx.fillStyle='#d8fbff';
    for(const chain of bones){hctx.beginPath();chain.forEach((id,i)=>{const l=landmarks[id],x=(1-l.x)*handCanvas.width,y=l.y*handCanvas.height;i?hctx.lineTo(x,y):hctx.moveTo(x,y);});hctx.stroke();}
    for(const id of [4,8]){const l=landmarks[id];hctx.beginPath();hctx.arc((1-l.x)*handCanvas.width,l.y*handCanvas.height,7,0,Math.PI*2);hctx.fill();}
    $('gestureState').textContent=pinch?'✦ PINCH DETECTED':'HAND FOUND · PINCH TO GRAB';
    if(pinch&&!handPinch&&!held)startGrab(p,'hand');
    else if(pinch&&held&&activeSource==='hand')moveGrab(p);
    else if(!pinch&&handPinch&&activeSource==='hand')endGrab();
    handPinch=pinch;
   }else{
    $('gestureState').textContent='SEARCHING FOR HAND…';gesturePos=null;
    if(handPinch&&activeSource==='hand')endGrab();handPinch=false;
   }
  }catch(err){console.warn('Tracking frame:',err);}
 }
 requestAnimationFrame(trackHands);
}
let lastTime=performance.now();
function render(t){
 const rect=canvas.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1);
 const w=rect.width,h=rect.height;
 if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
 ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
 const dt=Math.min(.05,(t-lastTime)/1000);lastTime=t;
 const grid=52;
 ctx.strokeStyle='rgba(84,147,190,.075)';ctx.lineWidth=1;
 for(let x=0;x<w;x+=grid){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();}
 for(let y=0;y<h;y+=grid){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
 const portalX=slot===1?0:w;
 const glow=ctx.createLinearGradient(slot===1?0:w-45,0,slot===1?55:w,0);
 glow.addColorStop(0,'rgba(47,181,255,.35)');glow.addColorStop(1,'rgba(47,181,255,0)');
 ctx.fillStyle=glow;ctx.fillRect(slot===1?0:w-55,0,55,h);
 ctx.strokeStyle='rgba(95,231,255,.7)';ctx.lineWidth=2;ctx.shadowBlur=18;ctx.shadowColor='#39d7ff';ctx.beginPath();ctx.moveTo(portalX,0);ctx.lineTo(portalX,h);ctx.stroke();ctx.shadowBlur=0;
 if(transferFlash>0){transferFlash=Math.max(0,transferFlash-dt*1.5);ctx.fillStyle=`rgba(110,229,255,${transferFlash*.1})`;ctx.fillRect(0,0,w,h);}
 if(state?.ball){
  const b=state.ball;
  if(b.owner===slot){
   const targetX=b.x,targetY=b.y;
   const blend=b.heldBy!==null?.52:.26;
   ballVisual.x=lerp(ballVisual.x,targetX,blend);ballVisual.y=lerp(ballVisual.y,targetY,blend);
   if(Math.abs(targetX-ballVisual.x)>.5||Math.abs(targetY-ballVisual.y)>.5){ballVisual.x=targetX;ballVisual.y=targetY;}
   const bx=ballVisual.x*w,by=ballVisual.y*h, radius=Math.max(18,Math.min(w,h)*.039);
   const light=ctx.createRadialGradient(bx,by,3,bx,by,radius*4);light.addColorStop(0,'rgba(64,224,255,.25)');light.addColorStop(1,'rgba(64,224,255,0)');ctx.fillStyle=light;ctx.fillRect(bx-radius*4,by-radius*4,radius*8,radius*8);
   ctx.beginPath();ctx.arc(bx,by,radius+7,0,Math.PI*2);ctx.strokeStyle=b.heldBy===slot?'rgba(132,255,220,.8)':'rgba(102,219,255,.2)';ctx.lineWidth=1.5;ctx.stroke();
   const orb=ctx.createRadialGradient(bx-radius*.36,by-radius*.43,2,bx,by,radius);orb.addColorStop(0,'#fff');orb.addColorStop(.25,'#c4fbff');orb.addColorStop(.55,'#5fe6ff');orb.addColorStop(1,'#0d6dba');ctx.fillStyle=orb;ctx.beginPath();ctx.arc(bx,by,radius,0,Math.PI*2);ctx.fill();
   ctx.strokeStyle='#d8ffff55';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(bx,by,radius*.64,b.spin||0,(b.spin||0)+Math.PI*.8);ctx.stroke();
  }
 }
 for(let i=particles.length-1;i>=0;i--){let p=particles[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=dt*.25;p.life-=dt*1.6;if(p.life<=0){particles.splice(i,1);continue;}ctx.globalAlpha=p.life;ctx.fillStyle='#83f4ff';ctx.beginPath();ctx.arc(p.x*w,p.y*h,p.r,0,Math.PI*2);ctx.fill();}ctx.globalAlpha=1;
 if(gesturePos&&handEnabled){const x=gesturePos.x*w,y=gesturePos.y*h;ctx.strokeStyle=handPinch?'#a7ffcf':'#7be9ff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y,handPinch?18:12,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(x-24,y);ctx.lineTo(x-16,y);ctx.moveTo(x+16,y);ctx.lineTo(x+24,y);ctx.moveTo(x,y-24);ctx.lineTo(x,y-16);ctx.moveTo(x,y+16);ctx.lineTo(x,y+24);ctx.stroke();}
 requestAnimationFrame(render);
}
requestAnimationFrame(render);
